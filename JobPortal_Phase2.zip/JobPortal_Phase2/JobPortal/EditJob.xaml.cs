﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entities;
using Job_BAL;
using Job_Exception;
using System.Data;

namespace JobPortal
{
    /// <summary>
    /// Interaction logic for EditJob.xaml
    /// </summary>
    public partial class EditJob : Window
    {
        public EditJob()
        {
            InitializeComponent();
        }

        private void UpdatingJob(object sender, RoutedEventArgs e)
        {
            UpdateJob();

        }

        private void Back(object sender, RoutedEventArgs e)
        {

        }

        private void ClearData(object sender, RoutedEventArgs e)
        {

        }

        private void Searching(object sender, RoutedEventArgs e)
        {
            SearchJob();

        }
        private void UpdateJob()
        {
            try
            {
                string Employer;
                string Address;
                string ContactNumber;
                string ContactEmailID;
                string SkillsRequired;
                string Qualification;
                string Location;
                long Salary;
                int NoOfVacancies;
                //
                bool jobUpdated;
                //
                Employer = txtEmployer.Text;
                Address = txtAddress.Text;
                ContactNumber = txtContactNumber.Text;
                ContactEmailID = txtContactEmailID.Text;
                SkillsRequired = txtSkillsRequired.Text;
                Qualification = txtQualification.Text;
                Location = txtLocation.Text;
                NoOfVacancies = Convert.ToInt32(txtNoOfVacancies.Text);
                Salary = Convert.ToInt64(txtNoOfVacancies.Text);
                //
                JobEntities objJobEntities = new JobEntities()
                {
                    Employer = Employer,
                    Address = Address,
                    ContactNumber = ContactNumber,
                    ContactEmailID = ContactEmailID,
                    SkillsRequired = SkillsRequired,
                    Qualification = Qualification,
                    Location = Location,
                    NoOfVacancies = NoOfVacancies,
                    Salary = Salary

                };
                jobUpdated = JPBAL.EditJobBL(objJobEntities);
                if (jobUpdated == true)
                {
                    MessageBox.Show("Employee record updated successfully.");
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be updated.");
                }
            }
            catch (JobExceptions jex)
            {
                throw jex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        private void SearchJob()
        {
            try
            {
                string JobID;
                //
                JobEntities objJobEntities;
                //
                JobID = txtJobID.Text;
                //
                objJobEntities = JPBAL.SearchJobBL(JobID);
                if (objJobEntities != null)
                {
                    txtEmployer.Text = objJobEntities.Employer;
                    txtAddress.Text = objJobEntities.Address;
                    txtContactNumber.Text = objJobEntities.ContactNumber;
                    txtContactEmailID.Text = objJobEntities.ContactEmailID;
                    txtSkillsRequired.Text = objJobEntities.SkillsRequired;
                    txtLocation.Text = objJobEntities.Location;
                    txtQualification.Text = objJobEntities.Qualification;
                    txtNoOfVacancies.Text = objJobEntities.NoOfVacancies.ToString();
                    txtSalary.Text = objJobEntities.Salary.ToString();
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be found.");
                }
            }
            catch (JobExceptions jex)
            {
                throw jex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
