﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entities;
using Job_BAL;
using Job_Exception;
using System.Data;
namespace JobPortal
{
    /// <summary>
    /// Interaction logic for NewUser.xaml
    /// </summary>
    public partial class NewUser : Window
    {
        public NewUser()
        {
            InitializeComponent();
        }

        private void Back(object sender, RoutedEventArgs e)
        {
            
        }

        private void Clearing(object sender, RoutedEventArgs e)
        {
            
        }

        private void AddingUser(object sender, RoutedEventArgs e)
        {
            AddUser();
        }
        private void AddUser()
        {
            try
            {

                bool userAdded;
                UserEntities objUserEntities = new UserEntities();
                {
                    objUserEntities.FirstName = txtFirstName.Text;
                    objUserEntities.LastName = txtLastName.Text;
                    objUserEntities.Password = txtPassword.Text;
                    objUserEntities.PhoneNo = txtPhoneNo.Text;
                    objUserEntities.Address = txtAddress.Text;
                    objUserEntities.Age = Convert.ToInt32(txtAge.Text);


                    if (rb_male.IsChecked == true)
                    {
                        objUserEntities.Gender = "M";
                    }
                    if (rb_female.IsChecked == true)
                    {
                        objUserEntities.Gender = "F";
                    }
                }

                userAdded = JPBAL.AddUserBL(objUserEntities);
                if (userAdded == true)
                {
                    MessageBox.Show("Employee record added successfully.");
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be added.");
                }
            }
            catch (JobExceptions jex)
            {
                throw jex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
