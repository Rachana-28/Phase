﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entities;
using Job_BAL;
using Job_Exception;
using System.Data;

namespace JobPortal
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }

       

       
        private void ClickToLogin(object sender, RoutedEventArgs e)
        {
            UserEntities objUserEntities = new UserEntities();
            JobEntities objJobEntities = new JobEntities();
            //objUserEntities.UserID = txtLoginid.Text;
            //objUserEntities.Password = txtPassword.Text;
            //objJobEntities.AdminID = txtLoginid.Text;
            //objJobEntities.AdminPassword = txtPassword.Text;
           if(rb_Admin.IsChecked==true)
            {
                string Login;
                string password;
                Login = txtLoginid.Text;
                password = txtPassword.Text;
                if(objJobEntities.AdminID==Login&&objJobEntities.AdminPassword==password)
                {
                    Admin a = new Admin();
                    a.ShowDialog();
                    this.Hide();
                }


                
            }
           if(rb_User.IsChecked==true)
            {
                string Login;
                string password;
                Login = txtLoginid.Text;
                password = txtPassword.Text;
                if (objUserEntities.UserID == Login && objUserEntities.Password == password)
                {
                    User u = new User();
                    u.ShowDialog();
                }


            }




        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Rb_User_Checked(object sender, RoutedEventArgs e)
        {

        }
    }
}
