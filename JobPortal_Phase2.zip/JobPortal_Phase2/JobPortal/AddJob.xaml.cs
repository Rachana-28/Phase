﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entities;
using Job_BAL;
using Job_Exception;
using System.Data;
namespace JobPortal
{
    /// <summary>
    /// Interaction logic for AddJob.xaml
    /// </summary>
    public partial class AddJob : Window
    {
        public AddJob()
        {
            InitializeComponent();
        }

        private void AddingJob(object sender, RoutedEventArgs e)
        {
            InsertJob();

        }

        private void Back(object sender, RoutedEventArgs e)
        {

        }
        private void InsertJob()
        {
            try
            {

                string Employer;
                string Address;
                string ContactNumber;
                string ContactEmailID;
                string SkillsRequired;
                string Qualification;
                string Location;
                double Salary;
                int NoOfVacancies;
                string JobName;
                int YearsOfExperience;
        //
        bool jobAdded;
                //
                JobName = txtJobName.Text;
                Employer = txtEmployer.Text;
                Address = txtAddress.Text;
                ContactNumber = txtContactNumber.Text;
                ContactEmailID = txtContactEmailID.Text;
                SkillsRequired = txtSkillsRequired.Text;
                Qualification = txtQualification.Text;
                Location = txtLocation.Text;
                NoOfVacancies = Convert.ToInt32(txtNoOfVacancies.Text);
                Salary = double.Parse(txtSalary.Text);
                YearsOfExperience = Convert.ToInt32(txtYearsOfExperience.Text);
                //

                JobEntities objJobEntities = new JobEntities()
                {
                    JobName = JobName,
                    Employer = Employer,
                    Address = Address,
                    ContactNumber = ContactNumber,
                    ContactEmailID=ContactEmailID,
                    SkillsRequired=SkillsRequired,
                    Qualification=Qualification,
                    Location=Location,
                    NoOfVacancies=NoOfVacancies,
                    Salary=Salary,
                    YearsOfExperience=YearsOfExperience

                };
                jobAdded = JPBAL.AddJobBL(objJobEntities);
                if (jobAdded == true)
                {
                    MessageBox.Show("Employee record added successfully.");
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be added.");
                }
            }
            catch (JobExceptions jex)
            {
                throw jex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
