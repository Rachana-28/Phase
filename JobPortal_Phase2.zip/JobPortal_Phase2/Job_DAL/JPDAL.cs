﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Job_Exception;
using Entities;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace Job_DAL
{
    public class JPDAL
    {
        public bool AddUserDAL(UserEntities objUserEntities)//new user
        {
            bool userAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);//change
                SqlCommand objCom = new SqlCommand("[dbo].[46008594_UserInsert]", objCon);//chnage
                objCom.CommandType = CommandType.StoredProcedure;
                //
                
                SqlParameter objSqlParam_Password = new SqlParameter("@Password", objUserEntities.Password);
                SqlParameter objSqlParam_FirstName = new SqlParameter("@FirstName", objUserEntities.FirstName);
                SqlParameter objSqlParam_LastName = new SqlParameter("@LastName", objUserEntities.LastName);
                SqlParameter objSqlParam_Address = new SqlParameter("@Address", objUserEntities.Address);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", objUserEntities.Age);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", objUserEntities.Gender);
                SqlParameter objSqlParam_PhoneNo = new SqlParameter("@PhoneNo", objUserEntities.PhoneNo);
          



                //

                objCom.Parameters.Add(objSqlParam_Password);
                objCom.Parameters.Add(objSqlParam_FirstName);
                objCom.Parameters.Add(objSqlParam_LastName);
                objCom.Parameters.Add(objSqlParam_Address);
                objCom.Parameters.Add(objSqlParam_Age);
                objCom.Parameters.Add(objSqlParam_Gender);
                objCom.Parameters.Add(objSqlParam_PhoneNo);
                
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                userAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new JobExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return userAdded;
        }
        public bool AddJobDAL(JobEntities objJobEntities)//admin adds jobdetails
        {
            bool jobAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);//change
                SqlCommand objCom = new SqlCommand("[dbo].[46008594_JobInsert]", objCon);//chnage
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_JobName = new SqlParameter("@JobName", objJobEntities.JobName);
                SqlParameter objSqlParam_Employer = new SqlParameter("@Employer", objJobEntities.Employer);
                SqlParameter objSqlParam_Location = new SqlParameter("@Location", objJobEntities.Location);
                SqlParameter objSqlParam_Salary = new SqlParameter("@Salary", objJobEntities.Salary);
                SqlParameter objSqlParam_Address = new SqlParameter("@Address", objJobEntities.Address);
                SqlParameter objSqlParam_ContactNumber = new SqlParameter("@ContactNumber", objJobEntities.ContactNumber);
                SqlParameter objSqlParam_ContactEmailId = new SqlParameter("@ContactEmailID", objJobEntities.ContactEmailID);//
                SqlParameter objSqlParam_SkillsRequired = new SqlParameter("@SkillsRequired", objJobEntities.SkillsRequired);
                SqlParameter objSqlParam_Qualification = new SqlParameter("@Qualification", objJobEntities.Qualification);
                SqlParameter objSqlParam_NoOfVaccancies = new SqlParameter("@NoOfVacancies", objJobEntities.NoOfVacancies);
                SqlParameter objSqlParam_YearsOfExperience = new SqlParameter("@YearsOfExperience", objJobEntities.YearsOfExperience);
                

                //
                
                objCom.Parameters.Add(objSqlParam_Employer);
                objCom.Parameters.Add(objSqlParam_Location);
                objCom.Parameters.Add(objSqlParam_Salary);
                objCom.Parameters.Add(objSqlParam_Address);
                objCom.Parameters.Add(objSqlParam_ContactNumber);
                objCom.Parameters.Add(objSqlParam_ContactEmailId);
                objCom.Parameters.Add(objSqlParam_SkillsRequired);
                objCom.Parameters.Add(objSqlParam_Qualification);
                objCom.Parameters.Add(objSqlParam_NoOfVaccancies);
                objCom.Parameters.Add(objSqlParam_YearsOfExperience);
                objCom.Parameters.Add(objSqlParam_JobName);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                jobAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new JobExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return jobAdded;
        }

        public bool EditJobDAL(JobEntities objJobEntities)  //admin edits job details
        {
            bool jobUpdated = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);//change
                SqlCommand objCom = new SqlCommand("[dbo].[46008594_JobEdit]", objCon);//change
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_JobName = new SqlParameter("@JobName", objJobEntities.JobName);
                SqlParameter objSqlParam_Employer = new SqlParameter("@Employer", objJobEntities.Employer);
                SqlParameter objSqlParam_Location = new SqlParameter("@Location", objJobEntities.Location);
                SqlParameter objSqlParam_Salary = new SqlParameter("@Salary", objJobEntities.Salary);
                SqlParameter objSqlParam_Address = new SqlParameter("@Address", objJobEntities.Address);
                SqlParameter objSqlParam_ContactNumber = new SqlParameter("@ContactNumber", objJobEntities.ContactNumber);
                SqlParameter objSqlParam_ContactEmailId = new SqlParameter("@ContactEmailID", objJobEntities.ContactEmailID);//
                SqlParameter objSqlParam_SkillsRequired = new SqlParameter("@SkillsRequired", objJobEntities.SkillsRequired);
                SqlParameter objSqlParam_Qualification = new SqlParameter("@Qualification", objJobEntities.Qualification);
                SqlParameter objSqlParam_NoOfVaccancies = new SqlParameter("@NoOfVacancies", objJobEntities.NoOfVacancies);
                SqlParameter objSqlParam_YearsOfExperience = new SqlParameter("@YearsOfExperience", objJobEntities.YearsOfExperience);
                //
                objCom.Parameters.Add(objSqlParam_JobName);
                objCom.Parameters.Add(objSqlParam_Employer);
                objCom.Parameters.Add(objSqlParam_Location);
                objCom.Parameters.Add(objSqlParam_Salary);
                objCom.Parameters.Add(objSqlParam_Address);
                objCom.Parameters.Add(objSqlParam_ContactNumber);
                objCom.Parameters.Add(objSqlParam_ContactEmailId);
                objCom.Parameters.Add(objSqlParam_SkillsRequired);
                objCom.Parameters.Add(objSqlParam_Qualification);
                objCom.Parameters.Add(objSqlParam_YearsOfExperience);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                jobUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new JobExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return jobUpdated;
        }

        public bool DeleteJobDAL(string JobName,int YearsOfExperience)    //admin deletes job by id
        {
            bool jobDeleted = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);//change
                SqlCommand objCom = new SqlCommand("[dbo].[46008594_JobDelete]", objCon);//change
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParameter_YearsOfExperience = new SqlParameter("@YearsOfExperience",YearsOfExperience);
                SqlParameter objSqlParam_JobName = new SqlParameter("@JobName", JobName);
                //
                objCom.Parameters.Add(objSqlParam_JobName);
                objCom.Parameters.Add(objSqlParameter_YearsOfExperience);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                if(objCom!=null)
                {
                    jobDeleted = true;
                }
                else
                {
                    jobDeleted = false;
                }
                
            }
            catch (SqlException objSqlEx)
            {
                throw new JobExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return jobDeleted;
        }

        public JobEntities SearchJobDAL(string id)  //user Search Job by years of experience and name
        {
            JobEntities objJobEntities = null;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["JPSConnectionString"].ConnectionString);//change
                SqlCommand objCom = new SqlCommand("[dbo].[46008594_SearchJob]", objCon);//change
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParameter_JobName = new SqlParameter("@JobName", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_Employer = new SqlParameter("@Employer", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_Location = new SqlParameter("@Location", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_Salary = new SqlParameter("@Salary", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_Address = new SqlParameter("@Address", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_ContactNumber = new SqlParameter("@ContactNumber", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_ContactEmailId = new SqlParameter("@ContactEmailID", SqlDbType.VarChar, 50);//
                SqlParameter objSqlParam_SkillsRequired = new SqlParameter("@SkillsRequired", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_Qualification = new SqlParameter("@Qualification", SqlDbType.VarChar, 50);

                SqlParameter objSqlParam_NoOfVaccancies = new SqlParameter("@NoOfVacancies", SqlDbType.Int);
                SqlParameter objSqlParam_YearsOfExperience = new SqlParameter("@YearsOfExperience", SqlDbType.Int);

                //
                objSqlParameter_JobName.Direction = ParameterDirection.Input;
                objSqlParam_Employer.Direction = ParameterDirection.Output;
                objSqlParam_Location.Direction = ParameterDirection.Output;
                objSqlParam_Salary.Direction = ParameterDirection.Output;
                objSqlParam_Address.Direction = ParameterDirection.Output;
                objSqlParam_ContactNumber.Direction = ParameterDirection.Output;
                objSqlParam_ContactEmailId.Direction = ParameterDirection.Output;
                objSqlParam_SkillsRequired.Direction = ParameterDirection.Output;
                objSqlParam_Qualification.Direction = ParameterDirection.Output;
                objSqlParam_NoOfVaccancies.Direction = ParameterDirection.Output;
                objSqlParam_YearsOfExperience.Direction = ParameterDirection.Input; 
                //
               
                objCom.Parameters.Add(objSqlParam_Employer);
                objCom.Parameters.Add(objSqlParam_Location);
                objCom.Parameters.Add(objSqlParam_Salary);
                objCom.Parameters.Add(objSqlParam_Address);
                objCom.Parameters.Add(objSqlParam_ContactNumber);
                objCom.Parameters.Add(objSqlParam_ContactEmailId);
                objCom.Parameters.Add(objSqlParam_SkillsRequired);
                objCom.Parameters.Add(objSqlParam_Qualification);
                objCom.Parameters.Add(objSqlParam_YearsOfExperience);
                //
               
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                objJobEntities = new JobEntities();
                objJobEntities.JobID = id;
                objJobEntities.JobName = objSqlParameter_JobName.Value as string;
                objJobEntities.Employer = objSqlParam_Employer.Value as string;
                objJobEntities.Location = objSqlParam_Location.Value as string;
                objJobEntities.Salary = Convert.ToInt32(objSqlParam_Salary.Value);
                objJobEntities.Address = objSqlParam_Address.Value as string;
                objJobEntities.ContactNumber = objSqlParam_ContactNumber.Value as string;
                objJobEntities.ContactEmailID = objSqlParam_ContactEmailId.Value as string;
                objJobEntities.SkillsRequired = objSqlParam_SkillsRequired.Value as string;
                objJobEntities.Qualification = objSqlParam_Qualification.Value as string;
                objJobEntities.NoOfVacancies = Convert.ToInt32(objSqlParam_NoOfVaccancies.Value);
                objJobEntities.YearsOfExperience = Convert.ToInt32(objSqlParam_YearsOfExperience.Value);

            }
            catch (SqlException objSqlEx)
            {
                throw new JobExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objJobEntities;
        }

        public List<JobEntities> GetAllJobDAL() //to print all jobs for user
        {
            List<JobEntities> objJobEntity = new List<JobEntities>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HRDSConnectionString"].ConnectionString);   //change
                SqlCommand objCom = new SqlCommand("SEmployees", objCon);//change
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    JobEntities objJobEntities = new JobEntities();
                    objJobEntities.JobID = objDR[0] as string;
                    objJobEntities.Employer = objDR[1] as string;
                    objJobEntities.Location = objDR[7] as string;
                    objJobEntities.Address = objDR[2] as string;
                    objJobEntities.ContactEmailID = objDR[4] as string;
                    objJobEntities.ContactNumber = objDR[3] as string;
                    objJobEntities.SkillsRequired = objDR[5] as string;
                    objJobEntities.Qualification = objDR[6] as string;
                    objJobEntities.JobID = objDR[0] as string;
                    objJobEntities.NoOfVacancies = Convert.ToInt32(objDR[9]);
                    objJobEntities.Salary = Convert.ToInt32(objDR[8]);
                    objJobEntity.Add(objJobEntities);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new JobExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objJobEntity;
        }

        //public DataTable GetDesignationsDAL()
        //{
        //    DataTable designationList = null;
        //    SqlConnection objCon = null;
        //    try
        //    {

        //        objCon = new SqlConnection(
        //            ConfigurationManager.ConnectionStrings["HRDSConnectionString"].ConnectionString);
        //        SqlCommand objCom = new SqlCommand("GDesignations", objCon);
        //        objCom.CommandType = CommandType.StoredProcedure;
        //        //
        //        objCon.Open();
        //        SqlDataReader objDR = objCom.ExecuteReader();
        //        designationList = new DataTable();
        //        designationList.Load(objDR);
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw new HRDSException(ex.Message);
        //    }
        //    finally
        //    {
        //        objCon.Close();
        //    }
        //    return designationList;
        //}

        //public DataTable GetDepartmentsDAL()
        //{
        //    DataTable departmentList = null;
        //    SqlConnection objCon = null;
        //    try
        //    {

        //        objCon = new SqlConnection(
        //            ConfigurationManager.ConnectionStrings["HRDSConnectionString"].ConnectionString);
        //        SqlCommand objCom = new SqlCommand("Gdepartment", objCon);
        //        objCom.CommandType = CommandType.StoredProcedure;
        //        //
        //        objCon.Open();
        //        SqlDataReader objDR = objCom.ExecuteReader();
        //        departmentList = new DataTable();
        //        departmentList.Load(objDR);
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw new HRDSException(ex.Message);
        //    }
        //    finally
        //    {
        //        objCon.Close();
        //    }
        //    return departmentList;
        //}


    }
}
