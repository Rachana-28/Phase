use Training_19Sep19_Pune;
go

create table [dbo].[46008594_User]
(
	UserID int IDENTITY(10,10) NOT NULL,
	Password varchar(20) NOT NULL,
	FirstName varchar(25) NOT NULL,
	LastName varchar(25) NOT NULL,
	Age int NOT NULL,
	Gender char NOT NULL,
	Address varchar(50) NOT NULL,
	PhoneNo varchar(10) NOT NULL,
	check(Gender in ('M', 'F')),
)

drop table [dbo].[46008594_User]

create table [dbo].[46008594_Job](
	JobID int IDENTITY(10,10) NOT NULL,
	JobName varchar(50) NOT NULL,
	Employer varchar(30) NOT NULL,
	Address varchar(25) NOT NULL,
	ContactNumber varchar(25) NOT NULL,
	ContactEmailID varchar(100) NOT NULL,
	SkillsRequired varchar(100) NOT NULL,
	Qualification varchar(50) NOT NULL,
	Location varchar(10) NOT NULL,
	Salary float NOT NULL,
	NoOfVacancies int NOT NULL,
	YearsOfExperience int NOT NULL,
)
 drop table [dbo].[46008594_Job]
--------------------------------------------Procedures for user--------------------------------------------------
create procedure [dbo]. [46008594_UserInsert]        
(
@Password varchar(25),
@FirstName varchar(25),
@LastName varchar(25),
@Age int,
@Gender char,
@Address varchar(50),
@PhoneNo varchar(50)

)
as
begin
insert into [dbo].[46008594_User]values(@Password,@FirstName,@LastName,@Age,@Gender,@Address,@PhoneNo)
end
drop procedure [dbo]. [46008594_UserInsert] 
-------------------------------------------------------DISPLAYUSER--------------------------------------
create procedure [dbo].[46008594_DisplayUser]
as
select * from [dbo].[46008594_User]
---------------------------------------------------------UPDATEUSER-------------------------------------
create procedure [dbo]. [46008594_UserEdit]        
(@UserID int,
@Password varchar,
@FirstName varchar,
@LastName varchar,
@Age int,
@Gender char,
@Address varchar,
@PhoneNo varchar

)
as
begin
update [dbo].[46008594_User] set Password=@Password,FirstName=@FirstName,LastName=@LastName,Age=@Age,Gender=@Gender,Address=@Address,PhoneNo=@PhoneNo where UserID=@UserID
end



-----------------------------------------------Procedures for Admin-------------------------------------------------
create procedure [dbo]. [46008594_JobInsert]
(
@JobName varchar(50),
 @Employer varchar(30), 
@Address varchar(25),
@ContactNumber varchar(25), 
@ContactEmailID varchar(100),
@SkillsRequired varchar(100),
@Qualification varchar(50), 
@Location varchar(10),
@Salary float,
@NoOfVacancies int,
@YearsOfExperience int
)
as
begin
insert into [dbo].[46008594_Job] values( @JobName,@Employer,@Address,@ContactNumber,@ContactEmailID,@SkillsRequired,@Qualification,@Location,@Salary,@NoOfVacancies,@YearsOfExperience)
end
drop procedure [dbo]. [46008594_JobInsert]
---------------------------------------------------------------UPDATEJOB------------------------------------------------------
create PROCEDURE [dbo].[46008594_JobEdit]
(

@JobName varchar(50),
 @Employer varchar(30), 
@Address varchar(25),
@ContactNumber varchar(25), 
@ContactEmailID varchar(100),
@SkillsRequired varchar(100),
@Qualification varchar(50), 
@Location varchar(10),
@Salary float,
@NoOfVacancies int,
@YearsOfExperience int
)

AS
begin

	update [dbo].[46008594_Job] set Employer=@Employer,Address=@Address,ContactNumber=@ContactNumber,ContactEmailID=@ContactEmailID,SkillsRequired=@SkillsRequired,Qualification=@Qualification,Location=@Location,Salary=@Salary,NoOfVacancies=@NoOfVacancies where JobName=@JobName or YearsOfExperience=@YearsOfExperience 
end
drop PROCEDURE [dbo].[46008594_JobEdit]
------------------------------------------------------DELETEJOB--------------------------------------------------------
create procedure [dbo].[46008594_JobDelete]
(
@JobName varchar(50),
	@YearsOfExperience int

)
as
begin
delete from  [dbo].[46008594_Job] where ((JobName=@JobName) and (YearsOfExperience=@YearsOfExperience))
end
drop procedure [dbo].[46008594_JobDelete]

------------------------------------------------------------SEARCHJOB-------------------------------------------------

create procedure [dbo].[46008594_SearchJob]
(
 @JobName varchar(50),
	@YearsOfExperience int
)
AS
begin

	select * from [dbo].[46008594_Job] where JobName=@JobName and YearsOfExperience=@YearsOfExperience
	end
drop procedure [dbo].[46008594_SearchJob]
------------------------------------------------------------------DISPLAYJOBS-------------------------------------------------------

create procedure [dbo].[46008594_DisplayJobs]
as
begin
select * from [dbo].[46008594_Job]
end


